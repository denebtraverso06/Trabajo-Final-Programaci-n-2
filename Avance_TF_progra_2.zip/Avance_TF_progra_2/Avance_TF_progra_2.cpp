#include "pch.h"
#include "MiAmong.h"
using namespace System;
using namespace AvanceTFprogra2;
int main()
{
    Application::Run(gcnew MiAmong);
    return 0;
}
