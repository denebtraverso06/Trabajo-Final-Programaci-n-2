#pragma once
#include<iostream>
#include <Windows.h>
#include <MMSystem.h>
using namespace std;
using namespace System;
using namespace System::Drawing;
using namespace System::Collections::Generic;
using namespace System::Windows::Forms;
ref class CEnte {
protected:
	int dx, dy, ancho, alto;
	Bitmap^ imagen;
	System::Drawing::Rectangle area_dibujo;
public:
	CEnte(String^ ruta,int x, int y, int ancho, int alto) {
		imagen = gcnew Bitmap(ruta);
		this->area_dibujo = System::Drawing::Rectangle(x,y,ancho,alto);
		this->iniciar_song();
	}
	~CEnte() {
		this->terminar_song();
	}
	virtual void dibujar(Graphics^ g) {
		g->DrawImage(this->imagen, this->area_dibujo);
	}
	virtual void movimiento() {

	}
	void iniciar_song() {
		PlaySound(TEXT("musica\\suspense_music.wav"), NULL, SND_ASYNC | SND_FILENAME | SND_LOOP);
	}
	void terminar_song() {
		PlaySound(NULL, NULL, 0);
	}
	System::Drawing::Rectangle area_actual() {
		return System::Drawing::Rectangle(this->area_dibujo.X,this->area_dibujo.Y,this->ancho, this->ancho);
	}
	System::Drawing::Rectangle next_area() {
		return System::Drawing::Rectangle(this->area_dibujo.X + dx, this->area_dibujo.Y + dy, this->ancho, this->ancho);
	}
};

