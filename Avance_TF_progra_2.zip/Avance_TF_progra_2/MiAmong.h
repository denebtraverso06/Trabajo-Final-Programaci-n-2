#pragma once
#include "CEnte.hpp"
namespace AvanceTFprogra2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MiAmong
	/// </summary>
	public ref class MiAmong : public System::Windows::Forms::Form
	{
		Graphics^ graficador;
		BufferedGraphics^ buffer;
	private: System::Windows::Forms::Timer^ timer_menu;
	private: System::Windows::Forms::Button^ button1;
		   CEnte^ escenario;
	public:
		MiAmong(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//

			this->graficador = CreateGraphics();
			buffer = BufferedGraphicsManager::Current->Allocate(this->graficador, this->ClientRectangle);
			escenario = gcnew CEnte("imagenes\\fondo_terror.jpg", 0, 0, this->ClientRectangle.Width, this->ClientRectangle.Height);
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MiAmong()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::ComponentModel::IContainer^ components;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->timer_menu = (gcnew System::Windows::Forms::Timer(this->components));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// timer_menu
			// 
			this->timer_menu->Enabled = true;
			this->timer_menu->Tick += gcnew System::EventHandler(this, &MiAmong::animar_menu);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(243, 581);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(161, 82);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Iniciar";
			this->button1->UseVisualStyleBackColor = true;
			// 
			// MiAmong
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1008, 729);
			this->Controls->Add(this->button1);
			this->Name = L"MiAmong";
			this->Text = L"MiAmong";
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void animar_menu(System::Object^ sender, System::EventArgs^ e) {
		this->buffer->Graphics->Clear(Color::White);
		this->escenario->dibujar(this->buffer->Graphics);
		this->buffer->Render();
	}
	};
}
